/* Independent, completion-gated Blind-Struggle training. Does not mutate Basick or archive data. */
(()=>{
'use strict';
const KEY='bcc_blind_struggle_v2', START='2026-11-02';
const DAYS=[
 [['75 min','Blind essay','Write a closed-book IRAC answer; prioritize complete issue spotting.'],['45 min','Compare Answers A and B','Identify missed issues, inaccurate rules, and weak factual analysis.'],['30 min','Blind rule reconstruction','Recall governing rules without notes; check and correct.'],['15 min','Targeted essay reconstruction','Rewrite the weakest issue or application from memory.'],['15 min','Error Log and due reviews','Record mistakes and prioritize overdue retrieval within this block.']],
 [['30 min','Compare Answers A and B','Target the areas missed on Day 1.'],['45 min','Blind rule reconstruction','Retrieve elements, exceptions, distinctions and factual triggers.'],['45 min','Essay rewrite','Rewrite the most important portions from the original question.'],['30 min','Strategies & Tactics MCQs','Answer and review questions, including guessed answers.'],['30 min','Error Log and due reviews','Update errors and complete due retrieval within this block.']],
 [['45 min','New hypothetical / transfer','Apply the rules to a variation or new subissues.'],['30 min','Blind rule reconstruction','Retrieve key rules and exceptions without notes.'],['45 min','Essay reconstruction / application','Produce a fresh issue-and-analysis outline and audit it.'],['30 min','Strategies & Tactics MCQs','Practice and review mixed or targeted questions.'],['30 min','Error Log and due reviews','Consolidate corrections and handle due retrieval within this block.']]
];
const names=['Cold Examination','Reconstruction','Essay Mastery & Retention'];
const parse=x=>new Date(x+'T12:00:00');
const iso=d=>[d.getFullYear(),String(d.getMonth()+1).padStart(2,'0'),String(d.getDate()).padStart(2,'0')].join('-');
const add=(x,n)=>{const d=parse(x);d.setDate(d.getDate()+n);return iso(d)};
const fmt=x=>parse(x).toLocaleDateString('en-US',{weekday:'short',month:'short',day:'numeric',year:'numeric'});
const today=()=>iso(new Date());
const empty=()=>({index:0,day:0,start:START,completed:[],records:{},reviews:{},lastDayCompleted:null});
let state;try{state={...empty(),...JSON.parse(localStorage.getItem(KEY)||'{}')}}catch(e){state=empty()}
const save=()=>localStorage.setItem(KEY,JSON.stringify(state));
const essays=()=>{const out=[];for(let col=0;col<6;col++)for(let row=0;row<12;row++)out.push({subject:BASICK_SUBJECTS[row],date:BASICK_DATES[row][col],q:BASICK_QUESTIONS[row][col],col:col+1,row});return out};
const list=essays();
const record=i=>state.records[i]||(state.records[i]={tasks:{},draft:'',rewrite:'',errors:'',hours:{}});
const dayTasks=()=>DAYS[state.day]||[];
const el=id=>document.getElementById(id);
const text=(tag,value,cls)=>{const n=document.createElement(tag);n.textContent=value;if(cls)n.className=cls;return n};
const clear=n=>n.replaceChildren();
function reviewItems(){const r=[];state.completed.forEach(c=>{for(const offset of [3,5,7,14,21]){const key=`${c.index}-${offset}`,due=add(c.end||add(c.start,2),offset);r.push({key,index:c.index,offset,due,done:state.reviews[key]})}});if(state.index<72 && state.start && state.day>0){const i=state.index;for(const offset of [3,5,7,14,21]){const key=`${i}-${offset}`;r.push({key,index:i,offset,due:add(state.start,offset+2),done:state.reviews[key]})}}return r.sort((a,b)=>a.due.localeCompare(b.due))}
// Four-month calendar view over the existing Blind-Struggle review records.
let calendarShift=0;
function renderSpacedTracker(){
 const panel=el('struggle-spaced-tracker');if(!panel)return;
 clear(panel);
 const heading=text('div','','study-cal-header');
 const intro=document.createElement('div');intro.append(text('h3','Study Calendar · spaced repetition'),text('p','Blind-Struggle, Civil Procedure, and other logged study sessions. Three discovery days, then retrieval +3, +5, +7, +14, +21 after Day 3. Guided work is not blind mastery.','struggle-hint'));
 const nav=text('div','','study-cal-nav');
 for(const [label,delta] of [['← Previous',-4],['Today',null],['Next →',4]]){
  const btn=text('button',label);btn.type='button';btn.onclick=()=>{calendarShift=delta===null?0:calendarShift+delta;renderSpacedTracker()};nav.append(btn);
 }
 heading.append(intro,nav);panel.append(heading);
 const started=new Map();state.completed.forEach(c=>{if(Number.isInteger(c.index)&&c.start)started.set(c.index,c.start)});
 if(state.index<72&&state.start)started.set(state.index,state.start);
 const events=new Map();
 for(const [index,start] of started){const e=list[index];if(!e)continue;
  for(let d=1;d<=3;d++){const date=add(start,d-1);if(!events.has(date))events.set(date,[]);events.get(date).push({discovery:true,index,day:d,essay:e,due:date,done:d<3?!!state.completed.some(c=>c.index===index)||index<state.index||index===state.index&&state.day>=d:!!state.completed.some(c=>c.index===index)||index<state.index});}
  for(const offset of [3,5,7,14,21]){const key=`${index}-${offset}`,due=add(start,offset+2);
   if(!events.has(due))events.set(due,[]);
   events.get(due).push({key,index,offset,due,done:state.reviews[key],essay:e});
  }
 }
 // Cross-track sessions are separate from Blind-Struggle completion records.
 const EXTRA_KEY='baros_calendar_sessions_v1';
 const getExtra=()=>{try{const x=JSON.parse(localStorage.getItem(EXTRA_KEY)||'[]');return Array.isArray(x)?x:[]}catch{return []}};
 const extra=getExtra();
 const known={id:'rp-2026-11-16',date:'2026-11-16',subject:'Real Property',title:'July 2005 Q2 · covenants / equitable servitudes',mode:'guided',reviews:{},cycleDays:3};
 if(!extra.some(x=>x.id===known.id)){extra.push(known);localStorage.setItem(EXTRA_KEY,JSON.stringify(extra))}
 const cross=new Map();
 const push=(date,item)=>{if(!/^\d{4}-\d{2}-\d{2}$/.test(date))return;if(!cross.has(date))cross.set(date,[]);cross.get(date).push(item)};
 // Read existing Civil Procedure browser records; do not mark work completed unless recorded.
 try{const civ=JSON.parse(localStorage.getItem('baros_civpro_v1')||'{}');
  const titles=['Discovery','Pleadings','Service of process','Default judgments','Temporary remedies','Appeals','Preclusion','Venue and transfer','Class actions','Discovery sanctions'];
  for(const x of Object.values(civ.daily||{})){if(!x||!x.date)continue;const title=titles[Number(x.topic)]||'Daily doctrine';push(x.date,{label:'Civil Procedure · '+title,kind:'session'});
   for(const n of [3,5,7,14,21])push(add(x.date,n),{label:'Civ Pro · '+title+' · D+'+n,kind:'civ-review',done:!!x.reviews?.[n],date:x.date,topic:x.topic,offset:n});}
  for(const x of civ.sessions||[]){if(!x?.date||!x.name)continue;for(let d=1;d<=3;d++)push(add(x.date,d-1),{label:'Civ Pro essay · '+x.name+' · Discovery Day '+d,kind:'session'});
   for(const n of [3,5,7,14,21]){const due=add(x.date,n+2);push(due,{label:'Civ Pro · '+x.name+' · D+'+n,kind:'civ-essay-review',done:!!civ.notes?.['review:'+x.name+':'+due+':'+n],name:x.name,offset:n})}}
 }catch(e){console.warn('Calendar could not read Civil Procedure progress',e)}
 for(const x of extra){if(!x.date||!x.subject)continue;const days=x.cycleDays===3?3:1;
  for(let day=1;day<=days;day++)push(add(x.date,day-1),{label:x.subject+' · '+(x.title||'Study session')+' · Discovery Day '+day+(x.mode==='guided'?' (guided)':''),kind:'session'});
  for(const n of [3,5,7,14,21])push(add(x.date,n+days-1),{label:x.subject+' · retrieval +'+n+' after Day '+days,kind:'extra-review',id:x.id,offset:n,done:!!x.reviews?.[n]});}
 const controls=text('div','','study-cal-nav');
 const addBtn=text('button','+ Log study session');addBtn.type='button';addBtn.onclick=()=>{
  const date=window.prompt('Study date (YYYY-MM-DD)',today());if(!date)return;if(!/^\d{4}-\d{2}-\d{2}$/.test(date)||Number.isNaN(parse(date).getTime())){window.alert('Enter a valid YYYY-MM-DD date');return}
  const subject=window.prompt('Subject (e.g. Civil Procedure or Real Property)');if(!subject?.trim())return;
  const title=window.prompt('Topic or essay reference','Guided doctrine session');if(!title?.trim())return;
  const cycle=window.confirm('Is this a three-day discovery cycle? OK = three days; Cancel = one-day session.');const id='manual-'+Date.now();extra.push({id,date,subject:subject.trim(),title:title.trim(),mode:'logged',cycleDays:cycle?3:1,reviews:{}});localStorage.setItem(EXTRA_KEY,JSON.stringify(extra));renderSpacedTracker();
 };controls.append(addBtn);heading.append(controls);
 const base=parse(today());base.setDate(1);base.setMonth(base.getMonth()+calendarShift);
 const months=text('div','','study-cal-months');
 for(let m=0;m<4;m++){
  const first=new Date(base.getFullYear(),base.getMonth()+m,1,12);
  const year=first.getFullYear(),month=first.getMonth();
  const block=text('section','','study-cal-month');block.append(text('h4',first.toLocaleDateString('en-US',{month:'long',year:'numeric'})));
  const grid=text('div','','study-cal-grid');
  for(const day of ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'])grid.append(text('span',day,'study-cal-weekday'));
  for(let i=0;i<first.getDay();i++)grid.append(text('div','','study-cal-blank'));
  const total=new Date(year,month+1,0).getDate();
  for(let day=1;day<=total;day++){
   const date=iso(new Date(year,month,day,12));const items=events.get(date)||[];
   const cell=text('div','','study-cal-day');if(date===today())cell.classList.add('is-today');
   if(items.some(x=>!x.done&&x.due<today()))cell.classList.add('has-overdue');
   cell.append(text('strong',String(day),'study-cal-date'));
   for(const item of items){if(item.discovery){const label=text('div',`${item.essay.subject} · ${item.essay.date} Q${item.essay.q} · Discovery Day ${item.day}${item.done?' ✓':''}`,'study-cal-event study-cal-session');cell.append(label);continue;}const label=text('label','','study-cal-event');if(item.done)label.classList.add('is-done');
    const check=document.createElement('input');check.type='checkbox';check.checked=!!item.done;
    check.setAttribute('aria-label',`${item.essay.subject} ${item.essay.date} Q${item.essay.q}, D+${item.offset}, ${fmt(date)}`);
    check.addEventListener('change',()=>{if(check.checked)state.reviews[item.key]=today();else delete state.reviews[item.key];save();render()});
    const name=text('span',`${item.essay.subject} · ${item.essay.date} Q${item.essay.q} · D+${item.offset}`);
    label.append(check,name);cell.append(label);
   }
   for(const item of cross.get(date)||[]){const label=text('label','','study-cal-event');label.classList.add(item.kind==='session'?'study-cal-session':'study-cal-cross-review');if(item.done)label.classList.add('is-done');
    if(item.kind==='extra-review'){
     const check=document.createElement('input');check.type='checkbox';check.checked=!!item.done;check.setAttribute('aria-label',item.label+' '+date);
     check.onchange=()=>{const all=getExtra(),x=all.find(v=>v.id===item.id);if(!x)return;x.reviews=x.reviews||{};if(check.checked)x.reviews[item.offset]=today();else delete x.reviews[item.offset];localStorage.setItem(EXTRA_KEY,JSON.stringify(all));renderSpacedTracker()};label.append(check);
    }else if(item.kind==='civ-review'||item.kind==='civ-essay-review'){
     const check=document.createElement('input');check.type='checkbox';check.checked=!!item.done;check.setAttribute('aria-label',item.label+' '+date);
     check.onchange=()=>{try{const civ=JSON.parse(localStorage.getItem('baros_civpro_v1')||'{}');if(item.kind==='civ-review'){const x=Object.values(civ.daily||{}).find(v=>v.date===item.date&&String(v.topic)===String(item.topic));if(!x)return;x.reviews=x.reviews||{};if(check.checked)x.reviews[item.offset]=true;else delete x.reviews[item.offset]}else{civ.notes=civ.notes||{};const key='review:'+item.name+':'+date+':'+item.offset;if(check.checked)civ.notes[key]=true;else delete civ.notes[key]}localStorage.setItem('baros_civpro_v1',JSON.stringify(civ));renderSpacedTracker()}catch(e){console.warn('Could not update Civil Procedure review',e)}};label.append(check);
    }
    label.append(text('span',item.label));cell.append(label);
   }
   grid.append(cell);
  }
  block.append(grid);months.append(block);
 }
 panel.append(months);
 const overdue=[...events.values()].flat().filter(x=>!x.done&&x.due<today()).length;
 const foot=text('p',`${overdue} overdue review(s) across all started essays. Green = completed; peach = overdue. Unfinished reviews remain on their original dates.`, 'struggle-hint');panel.append(foot);
}
function render(){const i=state.index,finished=i>=72,essay=list[Math.min(i,71)],r=record(i);const projected=finished?(state.completed.at(-1)?.end||START):add(state.start,(72-i)*3-state.day-1);const completedHours=Object.values(state.records).reduce((sum,v)=>sum+Object.values(v.hours||{}).reduce((a,b)=>a+(Number(b)||0),0),0);const elapsedDays=Math.max(0,Math.floor((new Date(today()+'T12:00:00')-new Date(START+'T12:00:00'))/86400000)+1);const cumulativePlannedHours=elapsedDays*5;
 el('struggle-metrics').replaceChildren(...[['Completed essays',`${i} / 72`],['Completed training days',`${i*3+state.day} / 216`],['Actual logged essay hours',`${completedHours.toFixed(1)}`],['Cumulative planned study hours · 5/day',`${cumulativePlannedHours.toFixed(1)}`],['Estimated finish*',fmt(projected)]].map(([label,value])=>{const d=text('div','', 'struggle-metric');d.append(text('strong',value),text('span',label));return d}));
 const assignment=el('struggle-assignment');clear(assignment);assignment.append(text('strong',finished?'All 72 essay cycles completed':`${essay.subject} · ${essay.date} · Question ${essay.q}`),text('small',finished?'All cycles completed':`Essay ${i+1} of 72 · Column ${essay.col} · Day ${state.day+1} of 3 · Started ${fmt(state.start)} · 3h/day plan · finish date is an estimate`));
 renderSpacedTracker();
 const tabs=el('struggle-day-tabs');clear(tabs);names.forEach((name,n)=>{const b=text('button',`Day ${n+1} · ${name}`);b.type='button';if(n===state.day)b.classList.add('active');b.disabled=finished||n!==state.day;tabs.append(b)});
 const tasks=el('struggle-tasks');clear(tasks);if(!finished)dayTasks().forEach(([duration,title,description],n)=>{const div=text('div','', 'struggle-task'),input=document.createElement('input');input.type='checkbox';input.checked=!!r.tasks[`${state.day}-${n}`];input.addEventListener('change',()=>{r.tasks[`${state.day}-${n}`]=input.checked;save();render()});const label=document.createElement('label');label.append(text('strong',title),text('div',description,'struggle-hint'));div.append(input,label,text('small',duration));tasks.append(div)});
 // Retrieval is part of the final 15/30-minute task, not additional time.
 const budget=el('struggle-retrieval-budget');if(budget){clear(budget);
  if(!finished){const due=reviewItems().filter(x=>!x.done&&x.due<=today());
   budget.append(text('h3','Daily retrieval · included in the 3-hour plan'),
    text('p',`Day ${state.day+1}: use the final ${state.day===0?15:30}-minute Error Log/review block for due retrieval and corrections. Do not add another hour.`, 'struggle-hint'));
   const ruleCount=Number(window.barosDueRuleCount?.()||0);
   budget.append(text('p',`${due.length} essay review(s) due or overdue · ${ruleCount} Error Log rule(s) due. Unfinished items stay pending.`, 'struggle-hint'));
   const queue=text('div','','struggle-retrieval-queue');
   for(const x of due){const e=list[x.index],row=text('div','','struggle-review');
    row.append(text('strong',`Day ${x.offset} · ${e.subject} · ${e.date} Q${e.q}`),text('span',`Due ${fmt(x.due)} · retrieve blind before marking complete`));
    const button=text('button','Mark retrieval complete');button.type='button';button.onclick=()=>{state.reviews[x.key]=today();save();render()};row.append(button);queue.append(row)}
   if(!due.length)queue.append(text('p','No essay reviews due. Retrieve current-essay rules and due Error Log rules.','struggle-hint'));
   budget.append(queue);
   if(due.length>1)budget.append(text('p','Prioritize overdue reviews; carry unfinished work forward rather than exceeding 3 hours.','struggle-hint'));
   const link=document.createElement('a');link.href='#master-error-log';link.textContent='Go to Master Error Log';budget.append(link);
   budget.append(text('p','*Finish estimate assumes one training day per calendar day; actual completion depends on your pace.','struggle-hint'));
  }
 }
 const ready=!finished&&dayTasks().every((_,n)=>r.tasks[`${state.day}-${n}`]);el('struggle-next-day').disabled=!ready||finished;el('struggle-next-day').textContent=state.day===2?'Complete cycle & begin next essay':'Complete this training day';el('struggle-status').textContent=finished?'Program complete':ready?'All tasks checked. Ready to advance.':'Finish each required task before advancing.';
 for(const [id,key] of [['struggle-draft','draft'],['struggle-rewrite','rewrite'],['struggle-errors','errors']]){const field=el(id);field.disabled=finished;field.value=r[key]||'';field.oninput=()=>{r[key]=field.value;save()}}const hours=el('struggle-hours');hours.disabled=finished;hours.value=r.hours[state.day]||0;hours.onchange=()=>{r.hours[state.day]=Math.max(0,Math.min(3,Number(hours.value)||0));save();render()};
 const reviews=el('struggle-reviews');clear(reviews);const items=reviewItems().filter(x=>x.due<=today()||(!x.done&&x.due<=add(today(),21)));if(!items.length)reviews.append(text('p','No scheduled reviews yet.','struggle-hint'));items.forEach(x=>{const d=text('div','',`struggle-review ${x.done?'done':x.due<today()?'overdue':''}`),e=list[x.index];d.append(text('strong',`${fmt(x.due)} · Day ${x.offset} · ${e.subject}`),text('span',`${e.date} Q${e.q} · ${x.done?'Completed '+fmt(x.done):x.due<today()?'OVERDUE':x.due===today()?'DUE TODAY':'Upcoming'}`));if(!x.done){const b=text('button','Mark retrieval complete');b.type='button';b.onclick=()=>{state.reviews[x.key]=today();save();render()};d.append(b)}reviews.append(d)});
 const upcoming=el('struggle-upcoming');clear(upcoming);for(let k=i;k<Math.min(72,i+7);k++){const e=list[k],offset=k-i,start=add(state.start,offset*3+(offset? -state.day:0));const row=text('div','', 'struggle-upcoming-row');row.append(text('strong',`Essay ${k+1} · ${e.subject}`),text('span',`${e.date} Q${e.q} · ${fmt(start)} (projected)`));upcoming.append(row)}
}
function advance(){if(state.index>=72)return;const r=record(state.index);if(!dayTasks().every((_,n)=>r.tasks[`${state.day}-${n}`]))return;const actual=today();if(state.day===2){state.completed.push({index:state.index,start:state.start,end:actual});state.index++;state.day=0;state.start=state.index<72?add(actual,1):actual}else{state.day++;}state.lastDayCompleted=actual;save();render()}
document.addEventListener('DOMContentLoaded',()=>{if(!el('struggle-training'))return;el('struggle-next-day').onclick=advance;el('struggle-export').onclick=()=>{const blob=new Blob([JSON.stringify({exported:today(),blindStruggle:state},null,2)],{type:'application/json'});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='baros-blind-struggle-'+today()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000)};render()});
})();
